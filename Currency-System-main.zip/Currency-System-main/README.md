# Need Support?

[![Need Support?](https://i.imgur.com/fqKYWeV.png)](https://discord.gg/Z9Mxu72zZ6)

# How to install:
Drag [Money] to your resources folder and write start [Money] in your server cfg.

# Description
These resouces will allow you to withdraw, deposit or transfer money to other players. You can use atms, banks, or chat commands.

# Features
* /give command
* /pay command
* ATM UI
* Fleeca Bank UI
* Current balance UI
* Sound effects

# Image Preview
https://i.imgur.com/ItJS1QW.png

https://i.imgur.com/6NUoIXT.png

# Video Preview
https://youtu.be/c0ifU70x36U
